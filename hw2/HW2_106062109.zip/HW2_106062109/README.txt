Want to test question 1 : compile HW2_Q1,
Want to test question 1 : compile HW2_Q2,
