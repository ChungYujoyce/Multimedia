For the first question:
use HW3_Q1.m

--> choose your mode by enter a number:
 1: Full_search p=8 macroblock=8x8
 2: Full_search p=16 macroblock=8x8
 3: Full_search p=8 macroblock=16x16 
 4: Full_search p=16 macroblock=16x16 
 5: 3_Step_Search p=8 macroblock=8x8
 6: 3_Step_Search p=16 macroblock=8x8
 7: 3_Step_Search p=8 macroblock=16x16 
 8: 3_Step_Search p=16 macroblock=16x16 
 9:show PSNR SAD relationship 
 10: Leave


For the second question:
use HW3_Q2.m

--> choose your mode by enter a number:
 1: Full_search p=8 macroblock=8x8 (PSNR comparison)
 2: Leave
